# VulpeJS - Express Module > Passport Submodule
