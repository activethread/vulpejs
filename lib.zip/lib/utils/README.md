# VulpeJS - Utils Module
